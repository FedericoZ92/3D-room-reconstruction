﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Kinect; 
////////////////////////////////////////\\
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

using System.Windows.Media.Imaging;
////////////////////////////////////////\\


namespace KinectMLConnect
{
    public partial class KinectToMatlab : Form
    {
        #region Members
        /// <summary>
        /// Active Kinect sensor
        /// </summary>
        private KinectSensor kinectSensor = null;

        /// <summary>
        /// Reader for depth frames
        /// </summary>
        private DepthFrameReader depthFrameReader = null;

        /// <summary>
        /// Description of the data contained in the depth frame
        /// </summary>
        private FrameDescription depthFrameDescription = null;

        /// <summary>
        /// Intermediate storage for frame data
        /// </summary>
        public ushort[] depthFrameData = null;

        /// <summary>
        /// Reader for IR frames
        /// </summary>
        private InfraredFrameReader IRFrameReader = null;

        /// <summary>
        /// Description of the data contained in the depth frame
        /// </summary>
        private FrameDescription IRFrameDescription = null;

        /// <summary>
        /// Intermediate storage for frame data converted to color
        /// </summary>
        public ushort[] IRFrameData = null;


        /// <summary>
        /// Current status text to display
        /// </summary>
        private string textBoxText = null;

        /// <summary>
        /// Keep track of the frames
        /// </summary>
        private int frameCount;

        /// <summary>
        /// writes to output files
        /// </summary>
        private MATWriter matfw = null;

        /// <summary>
        /// String path to save the framefiles
        /// </summary>
        private string filePath = null;

        /// <summary>
        /// Timing of the frames
        /// </summary>
        private ushort[] timing = null;

        /// <summary>
        /// Control which type of data to recieve
        /// </summary>
        private string extractType = null;

        public int stop_int = 0;

        #endregion
        
        /// <summary>
        /// Calling the constructor
        /// </summary>
        public KinectToMatlab(){

            // get the kinectSensor object
            this.kinectSensor = KinectSensor.GetDefault();

            // open the reader for the depth frames
            this.depthFrameReader = this.kinectSensor.DepthFrameSource.OpenReader();

            // Open IR reader for IR frames
            this.IRFrameReader = this.kinectSensor.InfraredFrameSource.OpenReader();                      

            // wire handler for frame arrival
            this.IRFrameReader.FrameArrived += this.IR_Reader_FrameArrived;
            this.depthFrameReader.FrameArrived += this.Depth_Reader_FrameArrived;           

            // get FrameDescription from DepthFrameSource
            this.depthFrameDescription = this.kinectSensor.DepthFrameSource.FrameDescription;

            // get FrameDescription from InfraredFrameSOurce
            this.IRFrameDescription = this.kinectSensor.InfraredFrameSource.FrameDescription;

            // allocate space to put the pixels being received and converted
            this.depthFrameData = new ushort[this.depthFrameDescription.Width * this.depthFrameDescription.Height];

            // allocate space for IR frame
            this.IRFrameData = new ushort[this.IRFrameDescription.Width * this.IRFrameDescription.Height];

            // set IsAvailableChanged event notifier
            this.kinectSensor.IsAvailableChanged += this.Sensor_IsAvailableChanged;

            // open the sensor
            this.kinectSensor.Open();

            // initialize the components (controls) of the window
            this.InitializeComponent();

            // set system initial status
            this.StatusText = Properties.Resources.InitialStatusText;

            // framecount is zero
            this.frameCount = 0;

            // Create output directory
            System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab");

            // Choose options
            this.DepthRadio.CheckedChanged += new EventHandler(Options_CheckedChanged);
            this.IRRadio.CheckedChanged += new EventHandler(Options_CheckedChanged);

            // Run option
            this.extractType = "Depth";

            // Allocate timing table
            this.timing = new ushort[1000];

            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////\\
            KinectSensor _sensor;
            MultiSourceFrameReader _reader;

           _sensor = this.kinectSensor;

            if (_sensor != null)
            {
                _sensor.Open();
            }
            
            
            _reader = _sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Color |
                                             FrameSourceTypes.Depth |
                                             FrameSourceTypes.Infrared);
            _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;

        }




        /// <summary>
        /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////\\
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            // Get a reference to the multi-frame
            var reference = e.FrameReference.AcquireFrame();

            // Open color frame
            using (var Frame = reference.ColorFrameReference.AcquireFrame())
            {
                if (stop_int == 1)
                {
                    if (Frame != null)
                    {
                        filePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/RGBframe" + frameCount.ToString() + ".MAT";
                        this.matfw = new MATWriter("RGBmat", filePath, depthFrameData, Frame.FrameDescription.Height, Frame.FrameDescription.Width);
                    }
                }
            }

                
            // Open depth frame
            /*using (var frame = reference.DepthFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    // Do something with the frame...
                }
            }

            // Open infrared frame
            using (var frame = reference.InfraredFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    // Do something with the frame...
                }
            }*/
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////




        /// <summary>
        /// Handles the IR frame data arriving from the sensor
        /// </summary>
        private void IR_Reader_FrameArrived(object sender, InfraredFrameArrivedEventArgs e)
        {
            if (this.StatusText == Properties.Resources.RunningStatusText)
            {
                if (this.extractType == "IR")
                {
                    using (InfraredFrame IRFrame = e.FrameReference.AcquireFrame())
                    {
                        if (IRFrame != null)
                        {
                            // the fastest way to process the body index data is to directly access 
                            // the underlying buffer
                            using (Microsoft.Kinect.KinectBuffer IRbuffer = IRFrame.LockImageBuffer())
                            {

                                {
                                    IRFrame.CopyFrameDataToArray(IRFrameData);
                                    this.frameCount++;
                                    this.timing[frameCount] = (ushort)IRFrame.RelativeTime.Milliseconds;
                                    filePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/IRframe" + frameCount.ToString() + ".MAT";
                                    this.matfw = new MATWriter("IRmat", filePath, IRFrameData, IRFrame.FrameDescription.Height, IRFrame.FrameDescription.Width);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                SaveParamsToFile(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/Intrinsic parameters.txt");
                this.StatusText = Properties.Resources.SensorIsAvailableStatusText;
            }
        }

        /// <summary>
        /// Chnage options based on radio buttons
        /// </summary>
        private void Options_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;

            if (DepthRadio.Checked)
            {
                this.extractType = "Depth";
                this.IRRadio.Checked = false;
            }
            else if (IRRadio.Checked)
            {
                this.extractType = "IR";
                this.DepthRadio.Checked = false;
            }
        }

        /// <summary>
        /// Execute shutdown tasks
        /// </summary>
        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            if (this.depthFrameReader != null)
            {
                // DepthFrameReader is IDisposable
                this.depthFrameReader.Dispose();
                this.depthFrameReader = null;
            }

            if (this.kinectSensor != null)
            {
                this.kinectSensor.Close();
                this.kinectSensor = null;
            }
        }

        /// <summary>
        /// Handles the depth frame data arriving from the sensor
        /// </summary>
        private void Depth_Reader_FrameArrived(object sender, DepthFrameArrivedEventArgs e)
        {
            if (/*this.StatusText == Properties.Resources.RunningStatusText*/ stop_int == 1)
            {
                if(this.extractType == "Depth")
                {
                    using (DepthFrame depthFrame = e.FrameReference.AcquireFrame())
                    {
                        if (depthFrame != null)
                        {
                            ///////////////////////////////////////////////////////////////////////////////////////////////////\\                           
                            pictureBox1.Image = BitmapFromSource(DFToBitmapSource(depthFrame));                      
                            ///////////////////////////////////////////////////////////////////////////////////////////////////\\

                            // the fastest way to process the body index data is to directly access 
                            // the underlying buffer
                            using (Microsoft.Kinect.KinectBuffer depthBuffer = depthFrame.LockImageBuffer())
                            {                            
                                {
                                    depthFrame.CopyFrameDataToArray(depthFrameData);
                                    this.frameCount++;
                                    this.timing[frameCount] = (ushort)depthFrame.RelativeTime.Milliseconds;
                                    filePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/Depthframe" + frameCount.ToString() + ".MAT";
                                    this.matfw = new MATWriter( "depthmat",filePath, depthFrameData, depthFrame.FrameDescription.Height, depthFrame.FrameDescription.Width);
                                    ///////////////////////////////////\\
                                    //Bitmap depthbitmap = BitmapFromSource(ToBitmap(depthFrame));
                                    //depthbitmap.Save(filePath);
                                    ///////////////////////////////////\\    
                                    stop_int = 0;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                SaveParamsToFile(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/Intrinsic parameters.txt");
                this.StatusText = Properties.Resources.SensorIsAvailableStatusText;
            }
        }

        
       

        /*Bitmap DepthToBitmap(DepthFrame depthFrame )
        {
          WriteableBitmap colorBitmap;        
          
          colorBitmap = new WriteableBitmap(this.kinectSensor.DepthFrameSource.FrameDescription.Width, 
                                            this.kinectSensor.DepthFrameSource.FrameDescription.Height, 
                                            96.0, 96.0, System.Windows.Media.PixelFormats.Bgr32 , null);
          // Get the min and max reliable depth for the current frame
          int minDepth = depthFrame.DepthMinReliableDistance;
          int maxDepth = depthFrame.DepthMaxReliableDistance;

          // Convert the depth to RGB
          int colorPixelIndex = 0;
          for (int i = 0; i < this.depthFrameData.Length; ++i)
          {
              // Get the depth for this pixel
              //int depth = this.depthFrameData.Length;              

              // To convert to a byte, we're discarding the most-significant
              // rather than least-significant bits.
              // We're preserving detail, although the intensity will "wrap."
              // Values outside the reliable depth range are mapped to 0 (black).

              // Note: Using conditionals in this loop could degrade performance.
              // Consider using a lookup table instead when writing production code.
              // See the KinectDepthViewer class used by the KinectExplorer sample
              // for a lookup table example.
              byte intensity = (byte)(depth >= minDepth && depth <= maxDepth ? depth : 0);
              Bitmap b = BitmapFromWriteableBitmap(colorBitmap); 
              // Write out blue byte
              this.colorPixels[colorPixelIndex++] = intensity;

              // Write out green byte
              this.colorPixels[colorPixelIndex++] = intensity;

              // Write out red byte                        
              this.colorPixels[colorPixelIndex++] = intensity;

              // We're outputting BGR, the last byte in the 32 bits is unused so skip it
              // If we were outputting BGRA, we would write alpha here.
              ++colorPixelIndex;
          }


          return BitmapFromWriteableBitmap(colorBitmap);*/

            /*ushort[] pixelData = new ushort[imageFrame.FrameDescription.LengthInPixels];
            imageFrame.CopyFrameDataToArray(pixelData);

            Bitmap bmap = new Bitmap(
            imageFrame.FrameDescription.Width,
            imageFrame.FrameDescription.Height,
            PixelFormat.Format16bppRgb555);

            BitmapData bmapdata = bmap.LockBits(
             new Rectangle(0, 0, imageFrame.FrameDescription.Width,
                                    imageFrame.FrameDescription.Height),
             ImageLockMode.WriteOnly,
             bmap.PixelFormat);
            IntPtr ptr = bmapdata.Scan0;*/

            //int[] pixelDataint = Convert.ToInt32(pixelData);/////\\noooothis
            /*controlla cosa succede senza questa chiamata
            Marshal.Copy(pixelDataint,
             0,
             ptr,
             imageFrame.FrameDescription.Width *
               imageFrame.FrameDescription.Height);*/

            //bmap.UnlockBits(bmapdata);
            //return bmap;
        



        private System.Drawing.Bitmap BitmapFromWriteableBitmap(WriteableBitmap writeBmp)
        {
            System.Drawing.Bitmap bmp;
            using (System.IO.MemoryStream outStream = new System.IO.MemoryStream())
            {
                BitmapEncoder enc = new BmpBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create((BitmapSource)writeBmp));
                enc.Save(outStream);
                bmp = new System.Drawing.Bitmap(outStream);
            }
            return bmp;
        }

        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////\\
        /// </summary>
        /// <param name="frame"></param>
        /// <returns></returns>
        private BitmapSource DFToBitmapSource(DepthFrame frame)
        {
            int width = frame.FrameDescription.Width;
            int height = frame.FrameDescription.Height;

            ushort minDepth = frame.DepthMinReliableDistance;
            ushort maxDepth = frame.DepthMaxReliableDistance;

            ushort[] depthData = new ushort[width * height];
            byte[] pixelData = new byte[width * height * (System.Windows.Media.PixelFormats.Bgr32.BitsPerPixel + 7) / 8];
            
            frame.CopyFrameDataToArray(depthData);

            int colorIndex = 0;
            for (int depthIndex = 0; depthIndex < depthData.Length; ++depthIndex)
            {
                ushort depth = depthData[depthIndex];
                byte intensity = (byte)(depth >= minDepth && depth <= maxDepth ? depth : 0);

                pixelData[colorIndex++] = intensity; // Blue
                pixelData[colorIndex++] = intensity; // Green
                pixelData[colorIndex++] = intensity; // Red

                ++colorIndex;
            }

            int stride = width * System.Windows.Media.PixelFormats.Bgr32.BitsPerPixel / 8;/////////deve essere deciso meglio il formato, qui provvisorio bgr32

            return BitmapSource.Create(width, height, 96, 96, System.Windows.Media.PixelFormats.Bgr32, null, pixelData, stride);
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////\\

        private System.Drawing.Bitmap BitmapFromSource(BitmapSource bitmapsource)
        {
           System.Drawing.Bitmap bitmap;
           using (System.IO.MemoryStream outStream = new System.IO.MemoryStream())
           {
              BitmapEncoder enc = new BmpBitmapEncoder();
  
              enc.Frames.Add(BitmapFrame.Create(bitmapsource));
              enc.Save(outStream);
              bitmap = new System.Drawing.Bitmap(outStream);
           }
           return bitmap;
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////\\


        /// <summary>
        /// Actions on startup
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            //StopButton.Enabled = false;
            DepthRadio.Checked = true;
        }

        /// <summary>
        /// Actions on Start button click
        /// </summary>
        /// 
        //codice per pulsante START
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();       

        private void StartButton_Click(object sender, EventArgs e)
        {
            this.StatusText = Properties.Resources.RunningStatusText;
            StartButton.Enabled = false;
            //StopButton.Enabled = true;
            stop_int = 1;

            timer.Interval = 1000;
            timer.Tick += timer_Tick;
            timer.Start();
            timer.Enabled = true;
        }


         void timer_Tick(object sender, System.EventArgs e)
        {
            timer.Stop();
            timer.Enabled = false;
            StartButton.Enabled = true;
            this.StatusText = Properties.Resources.StoppedStatusText;
            stop_int = 0;
         }
         



        /// <summary>
        /// Actions on Stop button click
        /// </summary>
        /*private void StopButton_Click(object sender, EventArgs e)
        {
            StopButton.Enabled = false;
            StartButton.Enabled = true;
            this.StatusText = Properties.Resources.StoppedStatusText;

            this.matfw = new MATWriter("timing", Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Kinect to MatLab" + "/FrameTimings.mat", this.timing, this.timing.Length, 1);

            this.frameCount = 0;
            System.Array.Clear(this.timing, 0, this.timing.Length);
        }*/



        /// <summary>
        /// Listener for sensor availability
        /// </summary>
        private void Sensor_IsAvailableChanged(object sender, IsAvailableChangedEventArgs e)
        {
            if(e.IsAvailable == true)
            {
                this.StatusText = Properties.Resources.SensorIsAvailableStatusText;
            }
            else
            {
                this.StatusText = Properties.Resources.NoSensorStatusText;
            }
        }

        /// <summary>
        /// Listener for status changes (updates the status text)
        /// </summary>
        public string StatusText
        {
            get { return textBoxText; }
            set
            {
                textBoxText = value;
                {
                    this.StatusBox.Text = textBoxText;
                }
            }
        }

        /// <summary>
        /// Extracts the intrinsic parameters of the camera, to enable 3D point clouds
        /// </summary>
        private void SaveParamsToFile(string filePath)
        {
            // Get all the intrinsic parameters
            float Hfov = this.kinectSensor.DepthFrameSource.FrameDescription.HorizontalFieldOfView;
            float Vfov = this.kinectSensor.DepthFrameSource.FrameDescription.VerticalFieldOfView;
            float Dfov = this.kinectSensor.DepthFrameSource.FrameDescription.DiagonalFieldOfView;
            CameraIntrinsics camIntrinsics = this.kinectSensor.CoordinateMapper.GetDepthCameraIntrinsics();
            float Vfl = camIntrinsics.FocalLengthY;
            float Hfl = camIntrinsics.FocalLengthX;
            float Hpp = camIntrinsics.PrincipalPointX;
            float Vpp = camIntrinsics.PrincipalPointY;
            float Rdist = camIntrinsics.RadialDistortionSecondOrder;

            System.IO.File.WriteAllText(filePath,
                "Horizontal Field of View is: " + Hfov.ToString() + "\r\n" +
                "Vertical Field of View is: " + Vfov.ToString() + "\r\n" +
                "Diagonal Field of View is: " + Dfov.ToString() + "\r\n" +
                "Horizontal focal length is: " + Hfl.ToString() + "\r\n" + 
                "Vertical focal length is: " + Vfl.ToString() + "\r\n" +
                "Horizontal principle point is: " + Hpp.ToString() + "\r\n" +
                "Vertical Principal point is: " + Vpp.ToString() + "\r\n" +
                "Radial distortion Second order term is: "+ Rdist.ToString() + "\r\n");



        }

    }
}


